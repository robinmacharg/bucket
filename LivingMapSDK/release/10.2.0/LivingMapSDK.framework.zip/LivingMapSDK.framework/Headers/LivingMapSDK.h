#import <UIKit/UIKit.h>

//! Project version number for LivingMapSDK.
FOUNDATION_EXPORT double LivingMapSDKVersionNumber;

//! Project version string for LivingMapSDK.
FOUNDATION_EXPORT const unsigned char LivingMapSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LivingMapSDK/PublicHeader.h>


